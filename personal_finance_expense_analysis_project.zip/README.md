# Personal Finance & Expense Analysis

## 📊 Project Overview

This project analyzes monthly income and expenses to understand spending patterns, savings performance and budget variance.

The project combines Python-based data analysis with an Excel workbook that can be used as a simple personal-finance dashboard.

## 🎯 Objectives

- Track monthly income and expenses
- Analyze spending by category
- Calculate monthly savings
- Calculate savings rate
- Compare spending with category budgets
- Identify categories with budget variance
- Create visualizations for financial monitoring

## 🗂️ Dataset

The project contains 12 months of synthetic financial transactions across eight categories:

- Housing
- Food
- Transport
- Utilities
- Shopping
- Entertainment
- Healthcare
- Education

> **Note:** The dataset is synthetic and created for educational and portfolio purposes.

## 🛠️ Technologies Used

- Python
- Pandas
- NumPy
- Matplotlib
- Excel / OpenPyXL
- Exploratory Data Analysis
- Financial Analytics

## 📈 Analysis

### Monthly Income vs Expenses

![Income vs Expenses](income_vs_expenses.png)

### Spending by Category

![Spending by Category](spending_by_category.png)

### Monthly Savings

![Monthly Savings](monthly_savings.png)

## 💡 Key Insights

- Housing represents a major recurring expense.
- Monthly savings change according to income and spending levels.
- Budget variance highlights categories requiring attention.
- Savings rate provides a useful high-level financial health metric.
- Monthly tracking can help identify spending patterns early.

## 📊 Excel Workbook

`personal_finance_dashboard.xlsx` contains:

- **Transactions** — detailed expense records
- **Budgets** — monthly category budgets
- **Monthly Summary** — income, expenses, savings and savings rate
- **Category Summary** — category spending and budget variance

## ▶️ How to Run

Install the required packages:

```bash
pip install pandas numpy matplotlib openpyxl
```

Run:

```bash
python personal_finance_expense_analysis.py
```

## 📁 Project Structure

```text
personal-finance-expense-analysis/
├── expense_tracker_dataset.csv
├── category_budgets.csv
├── personal_finance_dashboard.xlsx
├── personal_finance_expense_analysis.py
├── income_vs_expenses.png
├── spending_by_category.png
├── monthly_savings.png
├── analysis_report.md
└── README.md
```

## ⚠️ Disclaimer

This project uses synthetic data for educational and portfolio purposes. It is not financial advice and does not represent real personal financial information.

## 👤 Author

**Snehil Raj**

B.Tech Electrical & Electronics Engineering  
Interested in Data Analytics, Business Analytics and Management.
