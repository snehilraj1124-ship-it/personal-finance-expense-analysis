# Personal Finance & Expense Analysis

## Objective
Analyze income, expenses, savings and category-level spending to understand personal financial patterns and budget performance.

## Dataset
- 12 months of synthetic transactions
- 8 spending categories
- Monthly income and expense tracking
- Separate monthly budget targets

## Key Results
- Total annual income: $57,957.64
- Total annual expenses: $53,090.11
- Total annual savings: $4,867.53
- Overall savings rate: 8.4%
- Highest spending category: Housing ($26,759.46)

## Budget Analysis
Categories exceeding their annual budget:
     Category  Total_Spending  Annual_Budget  Budget_Variance
    Education         3017.47           3000            17.47
Entertainment         2848.08           2640           208.08
      Housing        26759.46          26400           359.46
    Transport         3600.47           3600             0.47

## Business / Financial Insights
1. Housing is the largest recurring expense category in the synthetic dataset.
2. Monthly income and expenses vary across the year, creating changes in monthly savings.
3. Category-level budget variance helps identify areas where spending can be controlled.
4. Tracking savings rate provides a simple way to monitor financial progress.
5. A monthly dashboard makes it easier to identify unusual spending patterns early.

## Recommendations
- Set monthly spending limits for discretionary categories.
- Review categories with repeated positive budget variance.
- Track monthly savings rate rather than looking only at total spending.
- Maintain a separate emergency-fund target.
- Review the dashboard monthly and adjust budgets based on actual spending.

## Tools
Python, Pandas, NumPy, Matplotlib, Excel/OpenPyXL, Data Analysis and Financial Analytics.

## Disclaimer
This is synthetic educational portfolio data and is not financial advice or real personal financial data.
