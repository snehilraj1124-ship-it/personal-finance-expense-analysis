import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("expense_tracker_dataset.csv")
budget = pd.read_csv("category_budgets.csv")

monthly = df.groupby("Month").agg(
    Total_Expenses=("Amount", "sum"),
    Income=("Income", "first")
).reset_index()
monthly["Savings"] = monthly["Income"] - monthly["Total_Expenses"]
monthly["Savings_Rate_%"] = monthly["Savings"] / monthly["Income"] * 100

category = df.groupby("Category")["Amount"].agg(
    Total_Spending="sum",
    Avg_Monthly_Spending="mean"
).reset_index()
category = category.merge(budget, on="Category")
category["Annual_Budget"] = category["Monthly_Budget"] * 12
category["Budget_Variance"] = category["Total_Spending"] - category["Annual_Budget"]

print("Monthly Summary:\n", monthly.round(2))
print("\nCategory Summary:\n", category.round(2))

monthly.plot(x="Month", y=["Income", "Total_Expenses"], marker="o",
             figsize=(10,5), title="Monthly Income vs Expenses")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("income_vs_expenses.png", dpi=180)
plt.show()
